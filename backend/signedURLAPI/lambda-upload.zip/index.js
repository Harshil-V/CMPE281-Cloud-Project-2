const AWS = require('aws-sdk');

exports.handler = async (event) => {
    // Parse the JSON string from the request body
    const requestBody = event;
   
    // Extract bucket and file name from the request body
    const { bucket, fileName } = requestBody;

    // Set up the CloudFront and S3 clients
    const cloudfront = new AWS.CloudFront();
    const s3 = new AWS.S3();

    // // Get the CloudFront distribution ID associated with your CloudFront distribution
    // const distributionId = 'd1snit248jomq4.cloudfront.net';

    // // Set the CloudFront URL and path
    // const cloudFrontUrl = 'https://' + distributionId + '.cloudfront.net';
    // const cloudFrontPath = '/' + fileName;

    // // Generate a pre-signed CloudFront URL with a specified expiration time (in seconds)
    // const expirationTime = 300; // Adjust as needed
    // const params = {
    //     DistributionId: distributionId,
    //     Expires: Math.floor(Date.now() / 1000) + expirationTime,
    //     CustomPolicy: JSON.stringify({
    //         Statement: [
    //             {
    //                 Resource: cloudFrontUrl + cloudFrontPath,
    //                 Condition: {
    //                     DateLessThan: { 'AWS:EpochTime': Math.floor(Date.now() / 1000) + expirationTime },
    //                 },
    //             },
    //         ],
    //     }),
    // };

    try {
        // Get the pre-signed CloudFront URL
        // const signedUrl = await cloudfront.getSignedUrl(params);
        const signedUrl = await s3.getSignedUrl('getObject', {
            Bucket: bucket,
            Key: fileName,
            Expires: 3600,
        });

        // Return the signed URL in the response
        return signedUrl;
        // return {
        //     statusCode: 200,
        //     body: JSON.stringify({ signedUrl }),
        // };
    } catch (error) {
        console.error('Error generating pre-signed CloudFront URL:', error);

        // Return an error response
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Error generating pre-signed CloudFront URL' }),
        };
    }
};